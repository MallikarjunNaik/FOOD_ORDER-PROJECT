import React from 'react'

export default function Footer() {
  return (
    <>
      <footer>
        <p className='text-center'>
            Food Delivery Website - 2024-25, All Rights Reserved By Prasiddhi... 
        </p>
      </footer>
    </>
  );
}
